# Terrafox Data Lake Connector
A simple, secure wrapper module to stream files out of your private data lake into remote notebook runtimes seamlessly.
